<?php
/**
 * Phase 3 — AI configuration template.
 *
 * Copy to app/config/ai.php and fill in the key. app/config/ai.php is
 * git-ignored (see .gitignore) — the key must never reach version control,
 * a URL query string, or client-visible code (ROADMAP.md checklist).
 *
 * The GEMINI_API_KEY env var, when set, wins over the value here — that is
 * how CI and the test suite inject a fake key.
 */
declare(strict_types=1);

return [
    // 'gemini' is the only shipped provider; the interface allows others.
    'provider' => 'gemini',

    'gemini' => [
        // Confirm the exact model ID against Gemini's live model list before
        // deploying — model names churn (Phase 3 §9).
        'model' => 'gemini-3.6-flash',
        'api_key' => 'AQ.Ab8RN6L4QyCBwJtbSNMISff2_CzgZ2RfS1TPBqw6OsNNq-hpIw',
        'timeout_seconds' => 45,
    ],

    // §8 — caching + retry budget.
    'cache_ttl_seconds' => 600,     // 10 minutes: absorbs double-clicks
    'retry' => [
        'attempts' => 3,            // immediate, +10s, +60s
        'backoff_seconds' => [0, 10, 60],
    ],

    // §7 — when false, the UI hides Generate and shows manual-mode.
    'enabled' => true,
];
