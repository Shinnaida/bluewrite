<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database;
use App\Core\DraftProgress;
use App\Core\IncidentTypes;
use App\Core\LanguageRegistry;
use App\Core\ReportVerification;
use App\Core\Response;
use App\Core\RichText;
use App\Core\Station;
use App\Core\StationSeal;
use App\Core\Validator;
use App\Rules\ReportRules;
use PDO;

final class ReportsController
{
    /** Phase 1/2 legacy names — still accepted on input for old clients. */
    private const LEGACY_TYPES = ['Physical Injury', 'Vehicular Accident', 'Drug-related', 'Other'];

    /**
     * Owner request (2026-11-02): completeness never blocks — bypassed, not
     * deleted. The rules still exist and still run, but a BLANK field never
     * refuses a write. Shape validation (lengths, enums, formats, malformed
     * values) is untouched. Set false to restore refusal.
     */
    private const BYPASS_COMPLETENESS = true;

    /**
     * The reporting-party fields a finalize PATCH may leave out, because the
     * report already carries them. validateReporterParty() is given the stored
     * value for any of these the body does not send, so a PATCH that only flips
     * the status is checked against the row an officer has actually written
     * rather than against an empty body. Nothing here decides what a PATCH
     * writes — that stays with the keys the body carried.
     */
    private const PARTY_FIELDS = [
        'reporter_name',
        'reporter_contact',
        'reporter_address',
    ];

    /**
     * Phase 6 Stage 1 — the languages a narrative may be filed in (migration
     * 007). §8 Q2 of the plan settled on DECLARATION, and that was later
     * superseded by the owner: the client now DETECTS the language from the
     * narrative text and posts the result (detectNarrativeLanguage in
     * src/lib/reportLanguages.js).
     *
     * This server's part is unchanged by that reversal, and it is the part that
     * matters here: an incoming code is validated against the registry allowlist
     * and an unknown one is REJECTED with a 422 rather than coerced. The client's
     * detector is careful to return only codes the registry carries, but the API
     * does not take that on trust — a stored value is always one this system can
     * name, whatever a client sends.
     *
     * Phase 6 Stage 5 (Track A, D3) — the allowlist is read from the LANGUAGE
     * REGISTRY, not held here. resources/ai/language_registry.json is the single
     * source of truth shared with the client (via GET /me) and with the prompt's
     * per-call language line. No list is duplicated in this file any more.
     */

    /**
     * Every person a report can name, as [group path, name path] inside its
     * type_specific blob. Keep this in step with GROUP_CONFIG in
     * src/lib/incidentTypes.js: a group that carries a `name` (or a vehicle's
     * `driver_name`) but is missing here is a person the officer cannot find
     * the report by.
     *
     * `$.vehicle_N_driver` are the legacy flat Traffic Accident keys that
     * LegacyNormalizer reshapes into `vehicles[]`, so a report written before
     * the groups still answers to its driver's name (a NESTED PATH may match a
     * scalar — that is what the `$` field path is for).
     */
    private const SEARCH_PERSON_PATHS = [
        ['$.complainant[*]', '$.name'],
        // The representative who files on behalf of an organization victim is
        // a person too, and the sheet prints their name.
        ['$.complainant[*]', '$.representative_name'],
        ['$.respondent[*]', '$.name'],
        ['$.witness[*]', '$.name'],
        ['$.missing_person[*]', '$.name'],
        ['$.injured_persons[*]', '$.name'],
        ['$.arrested_persons[*]', '$.name'],
        ['$.person_last_seen_with[*]', '$.name'],
        ['$.vehicles[*]', '$.driver_name'],
        ['$.vehicle_1_driver', '$'],
        ['$.vehicle_2_driver', '$'],
    ];

    /**
     * A keyword search is ANDed word by word, and every word costs a LIKE per
     * field plus a term in the JSON scan. Past this many words it is a pasted
     * paragraph, not a search, and the statement built from it would be huge.
     */
    private const MAX_SEARCH_WORDS = 12;

    /**
     * Types this station accepts: the configured list (station_settings,
     * spec §1.1/§1.2 — the dropdown is station data, not code) plus the
     * legacy Phase 1/2 spellings.
     *
     * Public and static since Phase 7: the free-form account read
     * (POST /ai/classify) has to constrain the model to the SAME list this
     * controller validates a create against. A read that named a type the
     * create then rejects would be a dead end for the officer, and a second
     * copy of this list here is how the two would drift apart. Read-only —
     * nothing outside a request handler may mutate station settings through
     * it.
     *
     * @return string[]
     */
    public static function allowedTypes(): array
    {
        return array_values(array_unique(array_merge(Station::incidentTypes(), self::LEGACY_TYPES)));
    }

    /**
     * The narrative language off a request body, validated against the fixed
     * list, or null when the caller did not send one.
     *
     * null means "not provided", and the CALLER decides what that means: a
     * create stores the column's own default ('en', so a client that has never
     * heard of this field keeps working), while a PATCH leaves the stored value
     * alone. An unknown value is REJECTED with a 422, never coerced — a report
     * that says 'ceb' must not quietly become 'en', because the language is
     * what tells a reader the narrative is not English.
     */
    /**
     * How many incident types one report may carry. The client states the same
     * number (MAX_REPORT_TYPES in src/lib/incidentTypes.js) and the form will not
     * add a fifth; this is the copy that decides.
     */
    private const MAX_REPORT_TYPES = 4;

    /**
     * Does this database have the column? (`incident_types`, migration 020.)
     *
     * MIGRATION 020 IS NOT PART OF EVERY DATABASE YET, and every query that names
     * the column — the register's SELECT, the INSERT, the PATCH builder — answers
     * "Unknown column" on a deployment that has not applied it. The column is
     * therefore named only when INFORMATION_SCHEMA says it is there, which is the
     * same guard scripts/export-offline.php uses for reports.reporter_role.
     * Without it a station whose database is a migration behind cannot save ANY
     * report, which is a far worse failure than a compound incident being filed
     * under its primary type alone.
     */
    /**
     * Does this database have the table? (report_captures, migration 025.)
     *
     * The register names a per-row capture count (see index()) so Write
     * Report can offer the officer's waiting phone filings. A database a
     * migration behind has no such table, and the count is answered as zero
     * by leaving the column out rather than failing the whole register.
     */
    private function hasTable(PDO $pdo, string $table): bool
    {
        try {
            $probe = $pdo->prepare(
                "SELECT 1 FROM information_schema.TABLES
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t
                  LIMIT 1"
            );
            $probe->execute([':t' => $table]);
            return (bool) $probe->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }

    private function hasReportColumn(PDO $pdo, string $column): bool
    {
        try {
            $probe = $pdo->prepare(
                "SELECT 1 FROM information_schema.COLUMNS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reports' AND COLUMN_NAME = :c
                  LIMIT 1"
            );
            $probe->execute([':c' => $column]);
            return (bool) $probe->fetchColumn();
        } catch (Throwable $e) {
            // No rights on information_schema: take the safer half of the bet,
            // which is the one every deployment before 020 is in.
            return false;
        }
    }

    /**
     * Fold free-text incident types to their closest canonical type, keeping
     * the officer's exact words.
     *
     * The type box is typable and the camera / blotter read can name the
     * incident in legal words ("Reckless imprudence resulting to damage to
     * property and physical injury") that are on no list. Such text is folded
     * to the closest canonical type (IncidentTypes::closestType — the PHP
     * mirror of the form's own folding) so the folders, the filters and the
     * dashboard count the report under its main incident, and the exact words
     * ride along in type_specific.incident_category (the "Reported as" line).
     * Text with no real signal keeps the old answer — Other Incident specified
     * — and a station without the catch-all still refuses it, exactly as the
     * form does.
     *
     * @param array<string,mixed> $body request body, by value
     * @param array<string,string> $folded out: canonical type => raw words (first wins)
     * @return array<string,mixed> the body with folded types and injected Category
     */
    private function foldFreeTypes(array $body, array &$folded = []): array
    {
        $touchesTypes = array_key_exists('incident_types', $body) || array_key_exists('incident_type', $body);
        if (!$touchesTypes) {
            return $body;
        }
        $allowed = $this->allowedTypes();
        $foldOne = static function ($value) use ($allowed, &$folded) {
            if (!is_string($value)) {
                return $value;
            }
            $text = trim($value);
            if ($text === '' || in_array($text, $allowed, true)) {
                return $value;
            }
            $closest = IncidentTypes::closestType($text, $allowed);
            if ($closest === null) {
                if (!in_array('Other Incident', $allowed, true)) {
                    return $value; // refused below, as before
                }
                $closest = 'Other Incident';
            }
            if (!array_key_exists($closest, $folded)) {
                $folded[$closest] = $text;
            }
            return $closest;
        };
        if (is_array($body['incident_types'] ?? null) && array_is_list($body['incident_types'])) {
            $body['incident_types'] = array_values(array_map($foldOne, $body['incident_types']));
        } elseif (array_key_exists('incident_type', $body)) {
            $body['incident_type'] = $foldOne($body['incident_type']);
        }
        if ($folded !== []) {
            $ts = $body['type_specific'] ?? null;
            if (is_string($ts)) {
                $decoded = json_decode($ts, true);
                $ts = is_array($decoded) ? $decoded : [];
            }
            if (!is_array($ts)) {
                $ts = [];
            }
            if (trim((string) ($ts['incident_category'] ?? '')) === '') {
                $ts['incident_category'] = reset($folded);
            }
            $body['type_specific'] = $ts;
        }
        return $body;
    }

    /**
     * The incident types off a request body, primary first.
     *
     * TWO SHAPES, ONE ANSWER, so no client has to know about the other: a client
     * that sends `incident_types` (the form) gets that list, and a client that
     * sends only `incident_type` (every build before this one, and the API driven
     * by hand) gets a list of one. Order is the client's — the FIRST type is the
     * primary and is what `incident_type` is set to — blanks and repeats are
     * dropped rather than refused. Free text never reaches here unfolded:
     * foldFreeTypes() runs first, so an unknown name at this point is a 422,
     * never a coercion.
     *
     * @return string[] ready to be validated against allowedTypes()
     */
    private function incidentTypesFrom(array $body, Validator $v): array
    {
        $raw = $body['incident_types'] ?? null;
        if (is_array($raw) && array_is_list($raw)) {
            $candidates = $raw;
        } elseif (array_key_exists('incident_type', $body)) {
            $candidates = [$body['incident_type']];
        } else {
            return [];
        }

        $allowed = $this->allowedTypes();
        $list = [];
        foreach ($candidates as $value) {
            if (!is_string($value)) {
                Response::json(422, ['error' => 'Incident types must be text.']);
            }
            $type = trim($value);
            if ($type === '' || in_array($type, $list, true)) {
                continue;
            }
            if (!in_array($type, $allowed, true)) {
                $v->add('incident_types', "\"{$type}\" is not an incident type this station records.");
                continue;
            }
            $list[] = $type;
            if (count($list) >= self::MAX_REPORT_TYPES) {
                break;
            }
        }
        return $list;
    }

    private function narrativeLanguage(array $body, Validator $v): ?string
    {
        if (!array_key_exists('narrative_language', $body) || $body['narrative_language'] === null) {
            return null;
        }
        // $v->in() rejects a non-string as well as an unknown code, so both
        // misuses produce one clear message rather than a silent default.
        $v->in('narrative_language', $body['narrative_language'], LanguageRegistry::codes(), 'Narrative language');
        return is_string($body['narrative_language']) ? $body['narrative_language'] : null;
    }

    /**
     * Validate the type_specific JSON blob: object of scalar values PLUS
     * v3 group arrays (per GroupRules config). Keys snake_case, scalars max
     * 500 chars, group items validated per-instance by ReportRules.
     */
    /**
     * Completeness bypass (see BYPASS_COMPLETENESS): keep only the complaints
     * about MALFORMED values, dropping the complaints about blank fields. A
     * required-field refusal always names the requirement ("is required",
     * "required.", "must be recorded"); a shape refusal never does (see
     * ReportRules::checkValue()).
     *
     * @param string[] $errors
     * @return string[]
     */
    private static function shapeErrors(array $errors): array
    {
        return array_values(array_filter($errors, static function ($e): bool {
            return preg_match('/\brequired\b|must be recorded/i', (string) $e) !== 1;
        }));
    }

    private function sanitizeTypeSpecific(mixed $raw, string|array|null $incidentType = null, bool $finalizing = false): ?string
    {
        if ($raw === null) {
            return null;
        }
        if (is_string($raw)) {
            $raw = json_decode($raw, true);
        }
        if (!is_array($raw)) {
            Response::json(422, ['error' => 'type_specific must be a JSON object.']);
        }
        if (count($raw) > 64) {
            Response::json(422, ['error' => 'type_specific has too many fields.']);
        }

        // ONE REPORT, SEVERAL TYPES: every rule below that used to be asked of
        // the report's single type is asked of EACH of its types, and the blob
        // they see is the same one — the types' blocks share one namespace of
        // keys and one set of group lists, exactly as the client writes them.
        $types = $incidentType === null ? [] : (array) $incidentType;

        // Group keys are claimed by ReportRules; scalar keys handled here.
        $groupKeys = [];
        foreach ($types as $type) {
            if (!is_string($type) || $type === '') {
                continue;
            }
            foreach ((ReportRules::groupsFor($type) ?? []) as $gk => $ignored) {
                $groupKeys[$gk] = true;
            }
        }

        $clean = [];
        foreach ($raw as $k => $v) {
            if (!is_string($k) || !preg_match('/^[a-z0-9_]{1,60}$/', $k)) {
                Response::json(422, ['error' => "Invalid type_specific field name: {$k}"]);
            }
            if ($v === null || $v === '') {
                continue; // empty means absent
            }
            if (isset($groupKeys[$k])) {
                if (!is_array($v) || !array_is_list($v)) {
                    Response::json(422, ['error' => "type_specific.{$k} must be a list of entries."]);
                }
                if (count($v) > 50) {
                    Response::json(422, ['error' => "type_specific.{$k} has too many entries."]);
                }
                $cleanItems = [];
                foreach ($v as $item) {
                    if (!is_array($item)) {
                        Response::json(422, ['error' => "type_specific.{$k} entries must be objects."]);
                    }
                    $cleanItem = [];
                    foreach ($item as $ik => $iv) {
                        if (!is_string($ik) || !preg_match('/^[a-z0-9_]{1,60}$/', $ik)) {
                            Response::json(422, ['error' => "Invalid {$k} entry field: {$ik}"]);
                        }
                        if (is_array($iv)) {
                            Response::json(422, ['error' => "type_specific.{$k}.{$ik} must be a scalar value."]);
                        }
                        $cleanItem[$ik] = $iv === null ? '' : mb_substr(trim((string) $iv), 0, 500);
                    }
                    $cleanItems[] = $cleanItem;
                }
                $clean[$k] = $cleanItems;
                continue;
            }
            if (is_array($v)) {
                // Unknown array key (not a configured group) stays rejected.
                Response::json(422, ['error' => "type_specific.{$k} must be a scalar value."]);
            }
            $clean[$k] = mb_substr(trim((string) $v), 0, 500);
        }

        // Auto-fill the scalars the v3 groups superseded (Item, Owner of
        // Property, the legacy vehicle block…) BEFORE the rule pass, so what
        // gets validated is exactly what gets stored — and a client that only
        // sends the groups (the form) or only the flat scalars (an older build)
        // both end up with a report the sheet can print. See ReportRules::MIRRORS.
        foreach ($types as $type) {
            if (!is_string($type) || $type === '') {
                continue;
            }
            $clean = ReportRules::applyMirrors($clean, $type);
            // ...and take off a value the row is no longer SHOWING before it is
            // stored, not only before it is printed: a suspect recorded as
            // unidentified must not keep a name that the sheet, the AI context
            // and any export would then have to remember to ignore.
            $clean = ReportRules::stripHiddenGroupFields($clean);
        }

        // Gate 2: per-item rule validation, ONCE PER TYPE — a break-in that is
        // also a theft has to satisfy the break-in's rules and the theft's, and
        // both reports come back in one 422.
        $errors = [];
        foreach ($types as $type) {
            if (!is_string($type) || $type === '') {
                continue;
            }
            $errors = array_merge($errors, ReportRules::validateTypeSpecific($clean, $type, $finalizing));
        }
        // Completeness bypass (see BYPASS_COMPLETENESS): blank fields do not
        // refuse the write — only malformed values do.
        if ($errors !== [] && self::BYPASS_COMPLETENESS) {
            $errors = self::shapeErrors($errors);
        }
        if ($errors !== []) {
            Response::json(422, ['error' => 'The report has invalid fields.', 'details' => $errors]);
        }

        return $clean === [] ? null : json_encode($clean, JSON_UNESCAPED_UNICODE);
    }

    public function index(): void
    {
        $user = Auth::requireUser();
        $pdo = Database::pdo();

        // Archived list is Admin-only (restore is an Admin action).
        $showArchived = ($_GET['archived'] ?? null) === '1';
        if ($showArchived) {
            Auth::requireRole('Admin');
        }

        [$where, $params, $orderBy] = $this->listQueryFilters($user, $showArchived);

        // Pagination (UC-012).
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = min(100, max(5, (int) ($_GET['per_page'] ?? 10)));
        $offset = ($page - 1) * $perPage;

        $whereSql = implode(' AND ', $where);

        // Total count for pagination metadata (mirrors the same filters).
        $countStmt = $pdo->prepare(
            "SELECT COUNT(*) FROM reports r JOIN users u ON u.id = r.created_by WHERE {$whereSql}"
        );
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        // The reporting party's three fields, the disposition's two, the per-type
        // blob and the narrative are read for the DRAFT PROGRESS read-out and are
        // stripped again below, with the narrative the list has always dropped:
        // what leaves this endpoint is a count, not the officer's own words.
        // Migration 020's list is named only when the schema has it (see
        // hasReportColumn), so a database a migration behind still answers the
        // register instead of "Unknown column". The phone-filing count rides
        // the same guard for the report_captures table (migration 025).
        $hasTypes = $this->hasReportColumn($pdo, 'incident_types');
        $hasCaptures = $this->hasTable($pdo, 'report_captures');
        $captureSelect = $hasCaptures
            ? '(SELECT COUNT(*) FROM report_captures c WHERE c.report_id = r.id) AS capture_count, '
            : '';
        $sql = "SELECT r.id, r.incident_type, " . ($hasTypes ? 'r.incident_types, ' : '') . "r.report_date, r.blotter_no, r.blotter_date,
                    r.incident_datetime, r.incident_date, r.incident_time,
                    r.incident_time_approximate, r.location, r.status,
                    r.narrative_language, r.narrative_source_language,
                    r.created_by, u.full_name AS created_by_name, r.deleted_at,
                    r.narrative, r.narrative_source_text,
                    r.reporter_name, r.reporter_contact, r.reporter_address,
                    r.action_taken, r.ioc_name, r.type_specific,
                    {$captureSelect}r.id AS id_again
             FROM reports r JOIN users u ON u.id = r.created_by
             WHERE {$whereSql}
             ORDER BY {$orderBy}, r.id DESC
             LIMIT {$perPage} OFFSET {$offset}";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        // Phase 6 Stage 4 (D5) — the derived status is attached server-side, and
        // the narrative/source Text columns the derivation needs are then
        // STRIPPED: the list never carries narrative or source text (the same
        // rule the list has always followed).
        $rows = $this->attachVerificationStatus($pdo, $stmt->fetchAll());
        foreach ($rows as &$row) {
            // HOW FAR ALONG THE DRAFT IS, for the read-out on Home's cards. It is
            // derived from this row (never stored), so it is right for a draft any
            // client wrote, and it is attached BEFORE the columns it reads are
            // dropped below — the count leaves the endpoint, the fields do not.
            // Every row gets one, drafts and filed reports alike: nobody files a
            // half-written report, so the number is only ever interesting on a
            // draft, and the card divides by `total` either way.
            $row['progress'] = DraftProgress::forRow($row);
            // WHAT THE ROW CALLS ITS INCIDENT, decided HERE because the blob the
            // name is read out of is stripped on the next line: a report filed
            // under the catch-all type is listed under the officer's own words
            // for it ("Illegal Gambling"), and a compound report shows all of
            // its types. Both rules live in one place — app/core/IncidentTypes.php,
            // mirrored by src/lib/incidentTypes.js.
            $row['incident_type_label'] = IncidentTypes::label($row);
            $row['incident_types'] = IncidentTypes::listFrom($row);
            unset(
                $row['id_again'],
                $row['narrative'],
                $row['narrative_source_text'],
                $row['reporter_name'],
                $row['reporter_contact'],
                $row['reporter_address'],
                $row['action_taken'],
                $row['ioc_name'],
                $row['type_specific']
            );
        }
        unset($row);

        Response::json(200, [
            'reports' => $rows,
            'pagination' => [
                'page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => (int) max(1, ceil($total / $perPage)),
            ],
        ]);
    }

    /**
     * The register's FOLDER SHELF: how many reports of each incident type sit
     * on each status shelf, under exactly the filters the list itself uses.
     *
     * WHY ITS OWN ENDPOINT. The list is paged, so counting the rows it returns
     * answers for one page and not for the register; paging through every page
     * to tally in the browser would ship the whole blotter to the client to draw
     * a dozen numbers. One GROUP BY against the SAME filter pipeline gives the
     * shelf the truth about itself — which is also what makes a folder's count
     * and the list inside it impossible to disagree.
     *
     * It returns the raw (status, incident_type) tally rather than ready-made
     * buckets: which statuses share a shelf is the REGISTER's decision
     * (`statusBucket` in src/lib/reportFolder.js), and stating it a second time
     * here would be a second copy of the same rule.
     */
    public function folders(): void
    {
        $user = Auth::requireUser();
        $pdo = Database::pdo();

        // The archive is Admin-only, exactly as it is on the list itself.
        $showArchived = ($_GET['archived'] ?? null) === '1';
        if ($showArchived) {
            Auth::requireRole('Admin');
        }

        [$where, $params] = $this->listQueryFilters($user, $showArchived);
        $whereSql = implode(' AND ', $where);

        $stmt = $pdo->prepare(
            "SELECT r.status, r.incident_type, COUNT(*) AS n
             FROM reports r JOIN users u ON u.id = r.created_by
             WHERE {$whereSql}
             GROUP BY r.status, r.incident_type"
        );
        $stmt->execute($params);

        $folders = [];
        $total = 0;
        foreach ($stmt->fetchAll() as $row) {
            $n = (int) $row['n'];
            $total += $n;
            $folders[] = [
                'status' => (string) $row['status'],
                'incident_type' => (string) $row['incident_type'],
                'count' => $n,
            ];
        }

        Response::json(200, ['folders' => $folders, 'total' => $total]);
    }

    /**
     * CSV export of the report list (UC-013 companion). Reuses the exact
     * same filter/sort pipeline as index() — what you see is what you
     * export, including the non-admin own-reports scoping. No pagination:
     * an export that silently stops at page boundaries would mislead records
     * custodians. Streams in chunks so a large blotter can't exhaust memory.
     */
    public function exportCsv(): void
    {
        $user = Auth::requireUser();
        $pdo = Database::pdo();

        $showArchived = ($_GET['archived'] ?? null) === '1';
        if ($showArchived) {
            Auth::requireRole('Admin');
        }

        [$where, $params, $orderBy] = $this->listQueryFilters($user, $showArchived);
        $whereSql = implode(' AND ', $where);

        $stmt = $pdo->prepare(
            "SELECT r.id, r.incident_type, r.incident_datetime, r.location, r.status,
                    u.full_name AS created_by_name, r.complainant, r.respondent, r.deleted_at,
                    r.narrative_language, r.narrative_source_language,
                    r.narrative, r.narrative_source_text
             FROM reports r JOIN users u ON u.id = r.created_by
             WHERE {$whereSql}
             ORDER BY {$orderBy}, r.id DESC
             LIMIT 20000"
        );
        $stmt->execute($params);
        // Phase 6 Stage 4 — the export carries the derived verification STATUS
        // (label only). It NEVER carries the source text: adding it would widen
        // exposure, and the CSV has never carried the narrative either.
        $exportRows = $this->attachVerificationStatus($pdo, $stmt->fetchAll());
        $stmt = null;

        if (ob_get_level() !== 0) {
            ob_end_clean();
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="bluewrite-reports-' . date('Ymd-His') . '.csv"');
        header('Cache-Control: no-store');

        $out = fopen('php://output', 'w');
        // UTF-8 BOM so Excel opens Filipino text (ñ, é) correctly.
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Report No.', 'Incident Type', 'Incident Datetime', 'Location', 'Status', 'Recorded By', 'Complainant', 'Respondent', 'Archived', 'Verification']);

        $exported = 0;
        foreach ($exportRows as $row) {
            fputcsv($out, [
                'BW-' . str_pad((string) $row['id'], 4, '0', STR_PAD_LEFT),
                $row['incident_type'],
                $row['incident_datetime'],
                $row['location'],
                $row['status'],
                $row['created_by_name'],
                $row['complainant'],
                $row['respondent'],
                $row['deleted_at'] !== null ? 'yes' : 'no',
                $row['verification_label'] ?? '',
            ]);
            $exported++;
        }
        fclose($out);

        Audit::log((int) $user['id'], 'report.export', 'report', null, 'csv export, ' . $exported . ' rows');
        exit;
    }

    /**
     * Shared WHERE/params/ORDER builder for index() and exportCsv(). Lives
     * in one place so the export can never drift from the visible list.
     * @return array{0: string[], 1: array<string, mixed>, 2: string}
     */
    private function listQueryFilters(array $user, bool $showArchived): array
    {
        $params = [];
        $where = ['r.deleted_at ' . ($showArchived ? 'IS NOT NULL' : 'IS NULL')];

        // Non-admin accounts see only the reports they recorded. Officers and
        // Admin see the whole station blotter (owner request: an officer can view every report,
        // and each row names the officer who recorded it). Editing stays
        // owner-only for everyone but Admin — see update(). Enforced HERE, in the
        // query, not just hidden in the UI.
        if (!in_array($user['role'], ['Admin', 'Officer'], true)) {
            $where[] = 'r.created_by = :uid';
            $params[':uid'] = (int) $user['id'];
        }

        // WHOSE REPORTS — one officer's own list, which is what the account page shows
        // an administrator. It reuses this query rather than adding a second one so that
        // the counts, the statuses and the derived verification state on that page are
        // the SAME numbers this list shows: a summary computed a second way is a summary
        // that eventually disagrees with the record it summarises (pagination.total is
        // therefore that officer's total, not the station's).
        //
        // ADMIN ONLY, AND REFUSED RATHER THAN IGNORED. A non-admin account is
        // already scoped to its own reports by the clause above; silently intersecting
        // the two would answer 200 with an empty blotter, which reads as "that colleague
        // has never recorded anything" rather than as "you may not ask that".
        $createdBy = (int) ($_GET['created_by'] ?? 0);
        if ($createdBy > 0) {
            if ($user['role'] !== 'Admin') {
                // A role gate, marked like the one in Auth::requireRole so the
                // workspace can recognise a session that no longer matches the
                // tab's own state and reconcile it (see lib/api.js).
                Response::json(403, [
                    'error' => 'Your account does not have permission to perform this action.',
                    'code' => 'forbidden',
                ]);
            }
            $where[] = 'r.created_by = :created_by';
            $params[':created_by'] = $createdBy;
        }

        // Phase 6 Stage 4 — the "awaiting verification" view: a MODE of this same
        // list. It shows translated reports with no verification yet, in the
        // source languages this account can read, and it deliberately lifts the
        // own-reports restriction (a second officer must be able to open a
        // translation they did not write). It is limited to reports that HAVE a
        // source, so it never widens access to ordinary reports.
        if (($_GET['verification'] ?? '') === 'awaiting') {
            $where = array_values(array_filter(
                $where,
                static fn (string $w): bool => !str_contains($w, 'r.created_by = :uid')
            ));
            unset($params[':uid']);
            $where[] = 'r.narrative_source_text IS NOT NULL';
            $where[] = 'NOT EXISTS (SELECT 1 FROM report_verifications v WHERE v.report_id = r.id)';

            $readable = array_values(array_filter(array_map(
                static fn ($c) => strtolower(trim($c)),
                explode(',', strtolower((string) ($user['languages_read'] ?? ''))),
            ), static fn ($c) => $c !== ''));
            if ($user['role'] !== 'Admin') {
                if ($readable === []) {
                    // The account reads no source language: nothing to review.
                    $where[] = '1 = 0';
                } else {
                    $place = [];
                    foreach ($readable as $i => $code) {
                        $key = ":rl{$i}";
                        $place[] = $key;
                        $params[$key] = $code;
                    }
                    $where[] = 'r.narrative_source_language IN (' . implode(', ', $place) . ')';
                }
            }
            $lang = strtolower(trim((string) ($_GET['language'] ?? '')));
            if ($lang !== '') {
                $where[] = 'r.narrative_source_language = :rlang';
                $params[':rlang'] = $lang;
            }
        }

        // Keyword search (UC-013): type, location, parties, creator, narrative.
        //
        // The query is split into WORDS and every word has to appear somewhere
        // in the record — AND between words, OR across the fields. Matching the
        // whole query as one phrase (what this did before) could only ever find
        // a name in its STORED spelling, and reports store their parties
        // "Last Name, First Name, M.I." (see the form's own placeholders) — so
        // "Ana Reyes", which is how the name is said, matched nothing while
        // "Reyes, Ana" did. Words can only ever WIDEN the result set: anything
        // that matched the phrase still matches each of its words.
        //
        // Distinct placeholders per column AND per word — native prepares
        // (EMULATE_PREPARES = false) don't allow reusing one named parameter
        // multiple times.
        $q = trim((string) ($_GET['q'] ?? ''));
        if ($q !== '') {
            $words = preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY);
            if (!is_array($words) || $words === []) {
                // Input that is not valid UTF-8: still a search, just one term.
                $words = [$q];
            }
            if (count($words) > self::MAX_SEARCH_WORDS) {
                Response::json(422, ['error' => 'Search is limited to ' . self::MAX_SEARCH_WORDS . ' words.']);
            }

            // WHICH WORDS NAME A REPORT, built once before the per-word loop.
            //
            // A report's number is not a column: it is the record's id, spelled
            // the way the app spells it (BW-0319 — see reportNumber() in the
            // register), and the register's search field promises it in as many
            // words ("Search by report number, location, or type…" — owner
            // request, 2026-10-07). The spelling is loose on purpose, because an
            // officer reading a stamped sheet types what is printed and one who
            // remembers it types what they remember: "BW-0319", "bw319", "0319"
            // and "319" are one number.
            //
            // THE PREFIX MAY STAND APART FROM THE DIGITS — "BW 0319" is two words,
            // and a search that ANDs its words would otherwise need "bw" to appear
            // somewhere in the record, which it never does. So a word that is just
            // the prefix takes the number off the word that follows it, and both
            // words then name the same record.
            $reportIdFor = [];
            foreach ($words as $wi => $word) {
                $digits = null;
                if (preg_match('/^(?:bw-?)?0*(\d{1,9})$/i', $word, $m) === 1) {
                    $digits = (int) $m[1];
                } elseif (preg_match('/^bw-?$/i', $word) === 1) {
                    $next = (string) ($words[$wi + 1] ?? '');
                    if (preg_match('/^0*(\d{1,9})$/', $next, $n) === 1) {
                        $digits = (int) $n[1];
                    }
                }
                if ($digits !== null) {
                    $reportIdFor[$wi] = $digits;
                }
            }

            $qCols = [
                'r.incident_type',
                'r.location',
                'r.complainant',
                'r.respondent',
                'r.narrative',
                'u.full_name',
                // The other two people a report names: the party who reported
                // (migration 006) and the investigator on case (004). A report
                // can carry the reporting party and no groups at all — and then
                // the only name on it was unfindable.
                'r.reporter_name',
                'r.ioc_name',
            ];

            // One JSON projection, shared by every word: the COLUMNS list does
            // not depend on what was typed, only the LIKE does.
            $jsonColumns = '';
            $jsonHaystack = [];
            foreach (self::SEARCH_PERSON_PATHS as $qi => $spec) {
                $col = 'qn' . $qi;
                $jsonColumns .= "NESTED PATH '{$spec[0]}' COLUMNS ({$col} VARCHAR(500) PATH '{$spec[1]}'), ";
                $jsonHaystack[] = 'jt.' . $col;
            }
            $jsonColumns = rtrim($jsonColumns, ', ');

            $parts = [];
            foreach ($words as $wi => $word) {
                $or = [];
                foreach ($qCols as $ci => $col) {
                    $key = ":q{$wi}_{$ci}";
                    $or[] = "{$col} LIKE {$key}";
                    $params[$key] = '%' . $word . '%';
                }

                // The officer's own words for the incident (the "Reported as"
                // line a fold keeps). A folded report is FILED under its
                // canonical type, so searching the blotter's legal phrasing
                // would otherwise find nothing. One scalar, never a row — so
                // a plain extraction, not part of the person-name scan below.
                $key = ":qcat{$wi}";
                $params[$key] = '%' . $word . '%';
                $or[] = "JSON_UNQUOTE(JSON_EXTRACT(r.type_specific, '$.incident_category')) LIKE {$key}";

                // v3 reports keep ALL parties — victims, suspects, witnesses,
                // drivers, missing/arrested persons — inside the type_specific
                // JSON groups; the legacy text columns only mirror the first
                // party. Search every person name in the blob so a report can be
                // found by ANY involved name (JSON_TABLE, MySQL 8+; NULL blobs
                // simply yield no rows).
                //
                // ONE EXISTS PER WORD, and it is an alternative *inside* that
                // word's group — not a condition on its own. A party name can
                // live nowhere else on the report, so a word only a person's
                // name carries has to be able to satisfy the word by itself.
                // (ANDing it to the group would demand the name appear in a
                // text column as well, and every name-only search would come
                // back empty.)
                //
                // The word is matched against the names joined by a newline —
                // a separator no single word can contain, so one word cannot
                // straddle two people.
                //
                // Implementation note: JSON_TABLE may only reference tables from
                // its OWN FROM clause, so the subquery self-joins reports (jr)
                // and correlates on jr.id = r.id — a direct JSON_TABLE(r.…)
                // inside EXISTS compiles but silently matches nothing.
                $key = ":qts{$wi}";
                $params[$key] = '%' . $word . '%';
                $or[] = 'EXISTS (SELECT 1 FROM reports jr, JSON_TABLE('
                    . "jr.type_specific, '\$' COLUMNS ("
                    . $jsonColumns
                    // NOTE: two closing parens here — the first closes the
                    // COLUMNS list, the second closes JSON_TABLE( before its
                    // alias. With only one, the whole statement is a syntax
                    // error and EVERY keyword search 500s.
                    . ")) jt WHERE jr.id = r.id AND CONCAT_WS('\\n', "
                    . implode(', ', $jsonHaystack) . ") LIKE {$key})";

                // A WORD THAT NAMES A REPORT matches the record it names (see
                // $reportIdFor above). It is an ALTERNATIVE INSIDE the word's
                // group, like the party-name EXISTS above, and for the same
                // reason: a report's number appears nowhere else ON the report,
                // so the word has to be able to satisfy itself.
                //
                // Digits only, cast to an int and bound as a parameter — nothing
                // typed here reaches the SQL as anything but a NUMBER, and the
                // pattern caps at nine digits so a long string of them cannot
                // overflow what the column holds.
                if (isset($reportIdFor[$wi])) {
                    $key = ":qid{$wi}";
                    $params[$key] = $reportIdFor[$wi];
                    $or[] = "r.id = {$key}";
                }

                $parts[] = '(' . implode(' OR ', $or) . ')';
            }

            $where[] = '(' . implode(' AND ', $parts) . ')';
        }

        // Incident-type filter.
        $type = trim((string) ($_GET['type'] ?? ''));
        if ($type !== '') {
            if (!in_array($type, $this->allowedTypes(), true)) {
                Response::json(422, ['error' => 'Unknown incident type filter.']);
            }
            $where[] = 'r.incident_type = :type';
            $params[':type'] = $type;
        }

        // Status filter. `submitted` sits between draft and finalized in
        // the workflow; `attention` is the dashboard's working set (anything
        // not yet finalized). Admin filters the review queue with these.
        //
        // `filed` IS THE OFFICER'S OWN ANSWER (owner request, 2026-10-13): the
        // officer's screens do not offer `submitted` at all — a report that has
        // left their hands is FINALIZED, one word — so their filter asks for
        // everything sent, which is the same set the `submitted` BUCKET below
        // holds. It is stated here rather than reusing that bucket because the
        // two are asked different questions (a list filter vs a shelf count) and
        // both run through this same $where, so a report cannot be counted on the
        // officer's shelf and missing from their filtered list.
        $status = trim((string) ($_GET['status'] ?? ''));
        if ($status !== '') {
            if ($status === 'attention') {
                $where[] = "r.status != 'finalized'";
            } elseif ($status === 'filed') {
                $where[] = "r.status IN ('submitted', 'finalized')";
            } elseif (in_array($status, ['draft', 'submitted', 'finalized'], true)) {
                $where[] = 'r.status = :status';
                $params[':status'] = $status;
            } else {
                Response::json(422, ['error' => 'Unknown status filter.']);
            }
        }

        // Folder bucket. The register's folder shelf asks a DIFFERENT question
        // from the status filter: "is this still being written, or has it gone
        // forward?" — so `submitted` is everything that has left the officer's
        // hands, and a finalized report (the locked end state of submitted)
        // belongs on that shelf too. Enforced here, in the same pipeline, so the
        // folder count, the contents list inside a folder and the CSV export
        // cannot disagree about which reports a shelf holds.
        $bucket = trim((string) ($_GET['bucket'] ?? ''));
        if ($bucket !== '') {
            if ($bucket === 'draft') {
                $where[] = "r.status = 'draft'";
            } elseif ($bucket === 'submitted') {
                $where[] = "r.status IN ('submitted', 'finalized')";
            } else {
                Response::json(422, ['error' => 'Unknown folder filter.']);
            }
        }

        // Date range (inclusive, on incident_datetime).
        $dateFrom = trim((string) ($_GET['date_from'] ?? ''));
        if ($dateFrom !== '') {
            if (\DateTime::createFromFormat('Y-m-d', $dateFrom) === false) {
                Response::json(422, ['error' => 'date_from must be YYYY-MM-DD.']);
            }
            $where[] = 'r.incident_datetime >= :date_from';
            $params[':date_from'] = $dateFrom . ' 00:00:00';
        }
        $dateTo = trim((string) ($_GET['date_to'] ?? ''));
        if ($dateTo !== '') {
            if (\DateTime::createFromFormat('Y-m-d', $dateTo) === false) {
                Response::json(422, ['error' => 'date_to must be YYYY-MM-DD.']);
            }
            $where[] = 'r.incident_datetime <= :date_to';
            $params[':date_to'] = $dateTo . ' 23:59:59';
        }

        // Sort (UC-014): hardcoded column map — user input never touches SQL
        // identifiers (same allowlist pattern as the UPDATE builders).
        $sortMap = [
            // Owner request: the register opens on the most recently EDITED
            // report, so `updated_at` (auto-touched on every save) is sortable.
            'updated_at' => 'r.updated_at',
            'incident_datetime' => 'r.incident_datetime',
            'incident_type' => 'r.incident_type',
            'status' => 'r.status',
            'created_by_name' => 'created_by_name',
        ];
        $sortKey = (string) ($_GET['sort'] ?? 'incident_datetime');
        if (!array_key_exists($sortKey, $sortMap)) {
            Response::json(422, ['error' => 'Unknown sort field.']);
        }
        $dir = strtolower((string) ($_GET['dir'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';

        return [$where, $params, "{$sortMap[$sortKey]} {$dir}"];
    }

    public function store(): void
    {
        $user = Auth::requireUser();
        $body = $this->jsonBody();
        // Free text folds to its main incident before anything validates — a
        // camera read of "Reckless imprudence …" must be acceptable, not a 422.
        $folded = [];
        $body = $this->foldFreeTypes($body, $folded);

        $v = new Validator();
        // THE REPORT'S TYPES, PRIMARY FIRST. `incident_types` is the list the
        // form sends; `incident_type` alone is every caller that predates it,
        // and the two are one report with one primary type either way. What is
        // stored in `incident_type` is the primary, so every existing reader
        // (folders, filters, sort, dashboard bands, the sheet) is untouched.
        $types = $this->incidentTypesFrom($body, $v);
        $v->require('incident_type', $types[0] ?? null, 'Incident type', 60);
        $v->in('incident_type', $types[0] ?? null, $this->allowedTypes(), 'Incident type');
        // The incident date/time may arrive either as the two document fields
        // (spec §1.2) or as the legacy combined incident_datetime.
        $officialFields = $this->officialFields($body, $v);
        $official = $officialFields['values'];
        if ($official['incident_date'] === null) {
            $v->datetime('incident_datetime', $body['incident_datetime'] ?? null, 'Date and time of incident');
        }
        $v->require('location', $body['location'] ?? null, 'Place of incident', 200);
        $v->optional('complainant', $body['complainant'] ?? null, 'Complainant', 120);
        $v->optional('respondent', $body['respondent'] ?? null, 'Respondent', 120);
        if (isset($body['narrative']) && !is_string($body['narrative'])) {
            Response::json(422, ['error' => 'Narrative must be text.']);
        }
        // Phase 6 Stage 1: the language the narrative is written in, DECLARED by
        // the officer. Absent means 'en' — the column's own default — so an
        // older client, and the API driven directly, keep working unchanged.
        $narrativeLanguage = $this->narrativeLanguage($body, $v) ?? 'en';
        // Disposition fields printed on the sheet (migration 004). Both are
        // optional: an officer may finalize without them.
        $v->optional('action_taken', $body['action_taken'] ?? null, 'Action taken / status', 4000);
        $v->optional('ioc_name', $body['ioc_name'] ?? null, 'Investigator-on-case', 120);
        // Migration 023 — the officer's free-typed letter body. Validated as
        // text through the letter subset (see RichText::sanitizeLetter); the
        // cap is MEDIUMTEXT's own, because a full letter of nested divs runs
        // an order of magnitude larger than a prose field. A database from
        // before 023 simply has nowhere to put it — the guarded writes below
        // leave it out there, and the sheet composes from the fields instead.
        $v->optional('letter_html', $body['letter_html'] ?? null, 'Letter text', 16777215);
        $typeSpecific = $this->sanitizeTypeSpecific(
            $body['type_specific'] ?? null,
            $types,
            ($body['status'] ?? 'draft') === 'finalized',
        );
        // Completeness bypass (see BYPASS_COMPLETENESS): blanks on the
        // report's own identity fields never refuse the CREATE either — a
        // finalize from an untouched form creates first, and that create
        // must not 422 on the same blanks the finalize itself excuses.
        // Only emptiness is excused: an unknown type, a malformed datetime
        // and every other shape still refuses below via fail().
        if (self::BYPASS_COMPLETENESS) {
            $v->dropBlankValueErrors($body);
        }
        $this->fail($v);

        $status = 'draft'; // created reports always start as drafts
        $pdo = Database::pdo();
        // Named only when the column exists (see hasReportColumn): a database a
        // migration behind still stores the report under its primary type.
        $hasTypes = $this->hasReportColumn($pdo, 'incident_types');

        // Legacy clients send one datetime; the document fields win when both
        // shapes arrive. An unknown time stays NULL rather than defaulting to
        // a midnight that would read as a recorded fact.
        $incidentDate = $official['incident_date'];
        $incidentTime = $official['incident_time'];
        if ($incidentDate === null) {
            $legacy = $this->normalizeDt((string) ($body['incident_datetime'] ?? ''));
            $incidentDate = substr($legacy, 0, 10);
            // A blank legacy datetime leaves no date at all: the DATE column
            // is NULLable, so unknown stores NULL — never '' (strict-mode
            // MySQL rejects '' for DATE) and never a fabricated day.
            if (trim((string) $incidentDate) === '') {
                $incidentDate = null;
            }
            // A bare date carries no time: the time stays NULL (unknown),
            // never a midnight that would read as a recorded fact.
            $incidentTime = strlen($legacy) > 10 ? substr($legacy, 11, 8) : null;
            if ($incidentTime === '' || $incidentTime === false) {
                $incidentTime = null;
            }
        }

        // Migration 023 — same guard as the list column above: a database a
        // migration behind still stores the report without the freed letter.
        $hasLetter = $this->hasReportColumn($pdo, 'letter_html');
        $stmt = $pdo->prepare(
            'INSERT INTO reports (created_by, incident_type' . ($hasTypes ? ', incident_types' : '') . ($hasLetter ? ', letter_html' : '') . ', report_date, blotter_no, blotter_date,
                                  incident_datetime, incident_date, incident_time, incident_time_approximate,
                                  discovery_date, discovery_time, discovery_time_approximate,
                                  location, complainant, respondent, narrative, narrative_language,
                                  action_taken, ioc_name,
                                  reporter_name, reporter_contact,
                                  reporter_address,
                                  type_specific, status)
             VALUES (:created_by, :type' . ($hasTypes ? ', :types' : '') . ($hasLetter ? ', :letter_html' : '') . ', :report_date, :blotter_no, :blotter_date,
                     :dt, :incident_date, :incident_time, :incident_time_approx,
                     :discovery_date, :discovery_time, :discovery_time_approx,
                     :loc, :comp, :resp, :narr, :narr_lang, :act, :ioc,
                     :reporter_name, :reporter_contact,
                     :reporter_address,
                     :ts, :status)'
        );
        $params = [
            ':created_by' => (int) $user['id'],
            // incident_type is NOT NULL: a report with no type yet stores ''
            // (the sheet and register render it untyped), never a NULL that
            // would violate the column. Bypass-only path: a supplied unknown
            // type still 422s above, so '' here always means "no type given".
            ':type' => $types[0] ?? '',
            ':report_date' => $official['report_date'] ?? date('Y-m-d'),
            ':blotter_no' => $official['blotter_no'],
            ':blotter_date' => $official['blotter_date'],
            ':dt' => $this->composeDatetime($incidentDate, $incidentTime),
            ':incident_date' => $incidentDate,
            ':incident_time' => $incidentTime,
            ':incident_time_approx' => $official['incident_time_approximate'] ? 1 : 0,
            ':discovery_date' => $official['discovery_date'],
            ':discovery_time' => $official['discovery_time'],
            ':discovery_time_approx' => $official['discovery_time_approximate'] ? 1 : 0,
            ':loc' => trim((string) $body['location']),
            ':comp' => isset($body['complainant']) && $body['complainant'] !== null ? trim((string) $body['complainant']) : null,
            ':resp' => isset($body['respondent']) && $body['respondent'] !== null ? trim((string) $body['respondent']) : null,
            ':narr' => (string) ($body['narrative'] ?? ''),
            ':narr_lang' => $narrativeLanguage,
            ':act' => isset($body['action_taken']) && $body['action_taken'] !== null ? trim((string) $body['action_taken']) : null,
            ':ioc' => isset($body['ioc_name']) && $body['ioc_name'] !== null ? trim((string) $body['ioc_name']) : null,
            ':reporter_name' => $official['reporter_name'],
            ':reporter_contact' => $official['reporter_contact'],
            ':reporter_address' => $official['reporter_address'],
            ':ts' => $typeSpecific,
            ':status' => $status,
        ];
        if ($hasTypes) {
            $params[':types'] = json_encode($types, JSON_UNESCAPED_UNICODE);
        }
        if ($hasLetter) {
            $params[':letter_html'] = RichText::sanitizeLetter($body['letter_html'] ?? '');
        }
        $stmt->execute($params);
        $id = (int) $pdo->lastInsertId();

        $this->snapshot($pdo, $id, (int) $user['id'], 'Report created (draft).');

        Audit::log((int) $user['id'], 'report.create', 'report', (string) $id, 'type: ' . implode(', ', $types));
        Response::json(201, [
            'report' => ['id' => $id, 'status' => $status],
            'warnings' => $officialFields['warnings'],
        ]);
    }

    public function update(string $id): void
    {
        $user = Auth::requireUser();
        $reportId = (int) $id;
        $body = $this->jsonBody();
        $pdo = Database::pdo();

        $report = $this->fetchReport($pdo, $reportId);
        if ($report === null) {
            Response::json(404, ['error' => 'Report not found.']);
        }

        // A retyped type box folds the same way a create does.
        $folded = [];
        $body = $this->foldFreeTypes($body, $folded);

        $isAdmin = $user['role'] === 'Admin';
        $isOwner = (int) $report['created_by'] === (int) $user['id'];

        // Finalized reports are locked for everyone except Admin.
        if ($report['status'] === 'finalized' && !$isAdmin) {
            Response::json(403, ['error' => 'This report is finalized and locked. Only an administrator can edit it.']);
        }
        // Non-admin accounts edit only their own reports.
        if (!$isAdmin && !$isOwner) {
            Response::json(403, ['error' => 'You can only edit reports you recorded.']);
        }
        // Only Admin and Officer may finalize.
        if (($body['status'] ?? null) === 'finalized' && !$isAdmin && $user['role'] !== 'Officer') {
            Response::json(403, ['error' => 'Your role does not have permission to finalize reports.']);
        }

        $v = new Validator();
        // THE REPORT'S TYPES AFTER THIS PATCH (see store()): the list when the
        // body carries one, else the single type, else what the row already has.
        // `incident_type` is set to the list's first, so the primary stays the
        // primary however the list is reordered.
        $types = array_key_exists('incident_types', $body) || array_key_exists('incident_type', $body)
            ? $this->incidentTypesFrom($body, $v)
            : (array) ($report['incident_type'] !== null && $report['incident_type'] !== '' ? [$report['incident_type']] : []);
        if (array_key_exists('incident_type', $body) || array_key_exists('incident_types', $body)) {
            $v->in('incident_type', $types[0] ?? null, $this->allowedTypes(), 'Incident type');
        }
        if (array_key_exists('incident_datetime', $body)) {
            $v->datetime('incident_datetime', $body['incident_datetime'], 'Date and time of incident');
        }
        // Official-document fields (spec §1.2). Each is independent: a PATCH
        // may update only the blotter reference, or only the time.
        $officialFields = $this->officialFields($body, $v, ($body['status'] ?? null) === 'finalized', $report);
        $official = $officialFields['values'];
        $touchesIncidentWhen = $official['incident_date'] !== null || $official['incident_time'] !== null;
        if ($touchesIncidentWhen) {
            $newDate = $official['incident_date'] ?? (string) ($report['incident_date'] ?? '');
            $newTime = $official['incident_time'] ?? ($report['incident_time'] !== null ? (string) $report['incident_time'] : null);
            $merged = ReportRules::validateOfficialFields([
                'report_date' => $official['report_date'] ?? (string) ($report['report_date'] ?? ''),
                'blotter_no' => $official['blotter_no'] ?? (string) ($report['blotter_no'] ?? ''),
                'blotter_date' => $official['blotter_date'] ?? (string) ($report['blotter_date'] ?? ''),
                'incident_date' => $newDate,
                'discovery_date' => $official['discovery_date'] ?? (string) ($report['discovery_date'] ?? ''),
            ]);
            foreach ($merged['errors'] as $field => $msg) {
                $v->add($field, $msg);
            }
        }
        $notedById = null;
        if (array_key_exists('noted_by_id', $body) && $body['noted_by_id'] !== null && $body['noted_by_id'] !== '') {
            if ($user['role'] !== 'Admin' && $user['role'] !== 'Officer') {
                Response::json(403, ['error' => 'Your role cannot designate the noting officer.']);
            }
            $notedById = (int) $body['noted_by_id'];
            $known = array_column(Station::personnel(), 'full_name', 'id');
            if (!isset($known[$notedById])) {
                $v->add('noted_by_id', 'Select the noting officer from the station personnel list.');
            }
        }
        if (array_key_exists('location', $body)) {
            $v->require('location', $body['location'], 'Place of incident', 200);
        }
        if (array_key_exists('complainant', $body)) {
            $v->optional('complainant', $body['complainant'], 'Complainant', 120);
        }
        if (array_key_exists('respondent', $body)) {
            $v->optional('respondent', $body['respondent'], 'Respondent', 120);
        }
        if (array_key_exists('action_taken', $body)) {
            $v->optional('action_taken', $body['action_taken'], 'Action taken / status', 4000);
        }
        // Migration 023 — same rule on PATCH: a freed letter the officer typed
        // on the paper must survive the save, through the same letter subset.
        if (array_key_exists('letter_html', $body)) {
            $v->optional('letter_html', $body['letter_html'], 'Letter text', 16777215);
        }
        if (array_key_exists('ioc_name', $body)) {
            $v->optional('ioc_name', $body['ioc_name'], 'Investigator-on-case', 120);
        }
        if (array_key_exists('status', $body)) {
            // Item 9: 'submitted' removed — no flow produces it in Phase 1
            // (draft → finalized only). Schema ENUM keeps it for now; no
            // migration needed since no row ever uses it.
            $v->in('status', $body['status'], ['draft', 'finalized'], 'Status');
        }
        // Phase 6 Stage 1: the declared narrative language. A PATCH that does
        // not send it leaves the stored value untouched (null = not provided,
        // see narrativeLanguage()); one that sends an unknown code is rejected.
        // The finalized lock above already settles who may change it: an Admin
        // can, and nobody else can touch a finalized report at all. The value
        // column itself is written by the allowlist below, like every other
        // column a PATCH may set; the validated value is kept for the audit
        // note below.
        $narrativeLanguage = $this->narrativeLanguage($body, $v);
        // Phase 6 Stage 3 (D1) — the kept ORIGINAL text and its language. They
        // are PAIRED: the resulting row must hold both, or neither. A PATCH
        // that sends one without the other (and without the stored value to
        // pair it with) is rejected, and clearing one clears both. The Apply
        // action sends both together; the pair rule stops any other caller
        // from leaving a language with no text or a text with no language.
        $sourceTouched = array_key_exists('narrative_source_text', $body)
            || array_key_exists('narrative_source_language', $body);
        $sourceText = null;
        $sourceLanguage = null;
        if ($sourceTouched) {
            $storedText = trim((string) ($report['narrative_source_text'] ?? '')) !== ''
                ? trim((string) $report['narrative_source_text']) : null;
            $storedLang = (string) ($report['narrative_source_language'] ?? '') !== ''
                ? (string) $report['narrative_source_language'] : null;
            $sourceText = array_key_exists('narrative_source_text', $body)
                ? (is_string($body['narrative_source_text']) && trim($body['narrative_source_text']) !== ''
                    ? trim($body['narrative_source_text']) : null)
                : $storedText;
            $sourceLanguage = array_key_exists('narrative_source_language', $body)
                ? (is_string($body['narrative_source_language']) && $body['narrative_source_language'] !== ''
                    ? (string) $body['narrative_source_language'] : null)
                : $storedLang;
            if ($sourceLanguage !== null && !LanguageRegistry::isKnown($sourceLanguage)) {
                $v->add('narrative_source_language', 'Original-text language must be one of '
                    . implode(', ', LanguageRegistry::codes()) . '.');
            }
            if (($sourceText === null) !== ($sourceLanguage === null)) {
                $v->add('narrative_source_language', 'An original text and its language must be set together (or both cleared).');
            }
        }
        $typeSpecific = array_key_exists('type_specific', $body)
            ? $this->sanitizeTypeSpecific(
                $body['type_specific'],
                $types,
                ($body['status'] ?? null) === 'finalized'
                    || (($body['status'] ?? null) === null && ($report['status'] ?? '') === 'finalized'),
            )
            : null;
        // Completeness bypass (see BYPASS_COMPLETENESS): blanks on the
        // report's own identity fields never refuse the write.
        if (self::BYPASS_COMPLETENESS) {
            $v->dropBlankValueErrors($body);
        }
        $this->fail($v);

        // If finalizing, the report must be complete — unless completeness is
        // bypassed (see BYPASS_COMPLETENESS): then nothing here refuses.
        if (($body['status'] ?? null) === 'finalized' && !self::BYPASS_COMPLETENESS) {
            $merged = array_merge($report, array_intersect_key($body, $report));
            $narrative = array_key_exists('narrative', $body) ? trim((string) $body['narrative']) : trim((string) $report['narrative']);
            if ($narrative === '') {
                Response::json(422, ['error' => 'Enter the narrative before finalizing.', 'field' => 'narrative']);
            }
            // Action Taken / Status and IOC hidden by owner request
            // (2026-11-02): no longer required to finalize. Stored when
            // supplied, never demanded.
            // Groups already stored on a draft are re-validated here. The
            // form validates the draft it is holding, but nothing guaranteed
            // the SAVED blob was still finalize-clean (a field could have
            // been written by an older client), and a finalized report is an
            // official document — it must not be signed off with rows that
            // fail the rule set. When the body carried type_specific, the
            // Gate 2 pass in sanitizeTypeSpecific() already covered it.
            if (!array_key_exists('type_specific', $body)) {
                $stored = $report['type_specific'] ?? null;
                $storedBlob = is_string($stored) ? json_decode($stored, true) : null;
                // An absent blob is NOT an exemption. "Nothing was recorded" is
                // precisely what the rules exist to catch, so an empty set is
                // validated like any other — otherwise a report that never had
                // a type_specific column value could be finalized with none of
                // its incident type's fields filled in.
                // …once per type (see sanitizeTypeSpecific): a compound report is
                // not complete until every one of its types is.
                $groupErrors = [];
                foreach ($types as $type) {
                    $groupErrors = array_merge(
                        $groupErrors,
                        ReportRules::validateTypeSpecific(is_array($storedBlob) ? $storedBlob : [], (string) $type, true)
                    );
                }
                // Completeness bypass (see BYPASS_COMPLETENESS): blank fields
                // do not refuse the write — only malformed values do.
                if ($groupErrors !== [] && self::BYPASS_COMPLETENESS) {
                    $groupErrors = self::shapeErrors($groupErrors);
                }
                if ($groupErrors !== []) {
                    Response::json(422, [
                        'error' => 'The report has invalid fields.',
                        'details' => $groupErrors,
                    ]);
                }
            }

            $missing = [];
            foreach (['incident_type', 'incident_datetime', 'location'] as $f) {
                if (!isset($merged[$f]) || trim((string) $merged[$f]) === '') {
                    $missing[] = $f;
                }
            }
            // The sheet certifies the incident DATE, so it must be known —
            // the legacy datetime path derives it for older clients.
            $incidentDate = array_key_exists('incident_date', $body)
                ? trim((string) $body['incident_date'])
                : trim((string) ($report['incident_date'] ?? ''));
            if ($incidentDate === '' && trim((string) ($merged['incident_datetime'] ?? '')) === '') {
                $missing[] = 'incident_date';
            }
            if ($missing !== []) {
                Response::json(422, ['error' => 'The report has missing fields and cannot be finalized.', 'fields' => $missing]);
            }
        }

        $sets = [];
        $params = [':id' => $reportId];

        // The list column is written only when the schema has it, and its value
        // is the types AFTER this patch rather than a list the body happened to
        // send (see $types above) — a PATCH that changes only the type gets the
        // column updated with the same one item.
        $hasTypes = $this->hasReportColumn($pdo, 'incident_types');
        // Migration 023 — guarded the same way: the write below only names
        // the column when the schema carries it.
        $hasLetter = $this->hasReportColumn($pdo, 'letter_html');
        if ($hasTypes && (array_key_exists('incident_types', $body) || array_key_exists('incident_type', $body))) {
            $sets[] = 'incident_types = :incident_types';
            $params[':incident_types'] = json_encode($types, JSON_UNESCAPED_UNICODE);
        }

        $map = [
            'incident_type' => 'incident_type',
            'incident_datetime' => 'incident_datetime',
            'location' => 'location',
            'complainant' => 'complainant',
            'respondent' => 'respondent',
            'narrative' => 'narrative',
            // Phase 6 Stage 1 — changed together with the narrative's language
            // declaration, and by the same rule (anyone who may edit the
            // report). Selecting it RELABELS the text: it never converts,
            // translates or re-processes a single character of it.
            'narrative_language' => 'narrative_language',
            'action_taken' => 'action_taken',
            'ioc_name' => 'ioc_name',
            'status' => 'status',
        ];
        if (array_key_exists('type_specific', $body)) {
            $sets[] = 'type_specific = :ts';
            $params[':ts'] = $typeSpecific;
        }
        foreach ($map as $key => $col) {
            if (array_key_exists($key, $body)) {
                $sets[] = "{$col} = :{$col}";
                $val = $body[$key];
                if (is_string($val)) {
                    $val = $col === 'incident_datetime' ? $this->normalizeDt($val) : trim($val);
                }
                // `incident_type` is the PRIMARY type after this patch, even
                // when the body sent only a list: the two columns cannot drift.
                if ($col === 'incident_type' && ($types[0] ?? null) !== null) {
                    $val = $types[0];
                }
                $params[":{$col}"] = $val;
            }
        }

        // Migration 023 — the freed letter's own text, sanitized through the
        // letter subset on the way in, so the record keeps ink, never markup.
        // An empty letter stores as-is: empty means "no override" and the
        // sheet composes from the fields, exactly as before.
        if ($hasLetter && array_key_exists('letter_html', $body)) {
            $sets[] = 'letter_html = :letter_html';
            $params[':letter_html'] = RichText::sanitizeLetter($body['letter_html'] ?? '');
        }

        // Phase 6 Stage 3 — the paired source fields, written explicitly so a
        // clear stores NULL rather than an empty string.
        if ($sourceTouched) {
            $sets[] = 'narrative_source_text = :nst';
            $params[':nst'] = $sourceText;
            $sets[] = 'narrative_source_language = :nsl';
            $params[':nsl'] = $sourceLanguage;
        }

        // Official-document fields. A NULL here means "clear this field" when
        // the key was sent explicitly, so check the key, not the value.
        $officialMap = [
            'report_date', 'blotter_no', 'blotter_date',
            'incident_date', 'incident_time', 'incident_time_approximate',
            'discovery_date', 'discovery_time', 'discovery_time_approximate',
            // Migration 006 — the Write Report screen's reporting party.
            'reporter_name', 'reporter_contact', 'reporter_address',
        ];
        foreach ($officialMap as $key) {
            if (!array_key_exists($key, $body)) {
                continue;
            }
            $sets[] = "{$key} = :{$key}";
            $params[":{$key}"] = match ($key) {
                'incident_time_approximate', 'discovery_time_approximate' => $official[$key] ? 1 : 0,
                // Blank input clears the field rather than storing an empty string.
                default => $official[$key],
            };
        }

        // incident_datetime stays the sortable key: recompute it whenever
        // either half of the document pair changes.
        if ($touchesIncidentWhen) {
            $sets[] = 'incident_datetime = :dt';
            $params[':dt'] = $this->composeDatetime(
                $official['incident_date'] ?? (string) ($report['incident_date'] ?? ''),
                $official['incident_time'] ?? ($report['incident_time'] !== null ? (string) $report['incident_time'] : null),
            );
        }

        // Noted By (spec §1.9): stored as a personnel reference, with the
        // name denormalised so the sheet never depends on the roster row
        // surviving. The approval transition itself is Part 4.
        if ($notedById !== null) {
            $known = array_column(Station::personnel(), 'full_name', 'id');
            $sets[] = 'noted_by_id = :nby';
            $params[':nby'] = $notedById;
            $sets[] = 'noted_by_name = :nbyname';
            $params[':nbyname'] = $known[$notedById] ?? null;
            $sets[] = 'noted_at = NOW()';
        }

        if ($sets !== []) {
            // Audit (spec §1.10): who last changed the record.
            $sets[] = 'updated_by = :uby';
            $params[':uby'] = (int) $user['id'];
            if (($body['status'] ?? null) === 'finalized' && $report['status'] !== 'finalized') {
                $sets[] = 'finalized_by = :fby';
                $params[':fby'] = (int) $user['id'];
                $sets[] = 'finalized_at = NOW()';
                // Panel IV: the reporting party's signature is dated when the
                // document is submitted, not when the draft was started.
                $sets[] = 'party_signed_at = NOW()';
            }
            $stmt = $pdo->prepare('UPDATE reports SET ' . implode(', ', $sets) . ' WHERE id = :id');
            $stmt->execute($params);

            $note = ($body['status'] ?? null) === 'finalized' && $report['status'] !== 'finalized'
                ? 'Report finalized.'
                : 'Report updated.';
            // Phase 3: record how the narrative was authored so AI-assisted
            // content is traceable in report_history (audit requirement).
            if (($body['narrative_source'] ?? null) === 'ai-assisted') {
                $note .= ' Narrative source: ai-assisted.';
            }
            // Phase 6 Stage 1 (D5, decision Q9): the officer's finalize
            // confirmation for a non-English narrative is recorded in this same
            // note — the history then says plainly that a narrative was filed
            // without a translation. No new column and no extra audit row: the
            // officer who finalized is already on the row and on this snapshot.
            // The language that takes effect is the PATCH's when it sent one,
            // else the stored value; an unknown code never reaches here (the
            // validator above answers 422 first).
            $noteLanguage = $narrativeLanguage ?? ($report['narrative_language'] ?? 'en');
            if (($body['status'] ?? null) === 'finalized' && $report['status'] !== 'finalized'
                && $noteLanguage !== 'en') {
                $note .= ' Narrative language: ' . $noteLanguage . ' (not translated).';
            }
            $this->snapshot($pdo, $reportId, (int) $user['id'], $note);
            Audit::log((int) $user['id'], 'report.update', 'report', (string) $reportId, implode('; ', array_keys($body)));
        }

        Response::json(200, ['ok' => true, 'warnings' => $officialFields['warnings']]);
    }

    /** Admin-only: bring an archived report back to the working set (Item 2). */
    public function restore(string $id): void
    {
        $user = Auth::requireRole('Admin');
        $reportId = (int) $id;
        $pdo = Database::pdo();

        // Restores target archived rows specifically — fetch without the
        // deleted_at IS NULL filter.
        $stmt = $pdo->prepare('SELECT * FROM reports WHERE id = :id AND deleted_at IS NOT NULL');
        $stmt->execute([':id' => $reportId]);
        $report = $stmt->fetch();
        if ($report === false) {
            Response::json(404, ['error' => 'Archived report not found.']);
        }

        $stmt = $pdo->prepare('UPDATE reports SET deleted_at = NULL WHERE id = :id');
        $stmt->execute([':id' => $reportId]);

        $this->snapshot($pdo, $reportId, (int) $user['id'], 'Report restored from archive.');
        Audit::log((int) $user['id'], 'report.restore', 'report', (string) $reportId);
        Response::json(200, ['ok' => true]);
    }

    /** Soft delete (archive) only — rows are never removed. */
    public function destroy(string $id): void
    {
        $user = Auth::requireUser();
        $reportId = (int) $id;
        $pdo = Database::pdo();

        $report = $this->fetchReport($pdo, $reportId);
        if ($report === null) {
            Response::json(404, ['error' => 'Report not found.']);
        }

        $isAdmin = $user['role'] === 'Admin';
        $isOwner = (int) $report['created_by'] === (int) $user['id'];
        if (!$isAdmin && !$isOwner) {
            Response::json(403, ['error' => 'You can only archive reports you recorded.']);
        }

        $stmt = $pdo->prepare('UPDATE reports SET deleted_at = NOW() WHERE id = :id');
        $stmt->execute([':id' => $reportId]);

        $this->snapshot($pdo, $reportId, (int) $user['id'], 'Report archived (soft delete).');
        Audit::log((int) $user['id'], 'report.archive', 'report', (string) $reportId);
        Response::json(200, ['ok' => true]);
    }

    /**
     * Phase 2 (UC-015/016): full single-report payload for the print-ready
n     * view. Roles outside Admin and Officer may print only their own
n     * reports; Admin and Officer may print any.
     * print any. Finalized reports include the finalization block
     * (finalized_by/at), drafts are labeled DRAFT.
     */
    /**
     * GET /reports/{id} — one report, read.
     *
     * THE READ THE SCREENS NEED, separated from printData on purpose. The print
     * endpoint records `report.print` in the audit trail because printing a
     * document is an act; opening the same record to read or continue it is not,
     * and a server-rendered edit form that audited every page load as a print
     * would make the trail lie about what happened at the station.
     *
     * The visibility rule is the print endpoint's, unchanged: the account that
     * recorded the report, an administrator, or a reader recorded as reviewing a
     * translation (see ReportVerification::mayViewForVerification). Narrative and
     * type_specific are included because this is the screen that edits them —
     * unlike the list, which deliberately carries neither.
     */
    public function show(string $id): void
    {
        $user = Auth::requireUser();
        $pdo = Database::pdo();

        $stmt = $pdo->prepare(
            'SELECT r.*, u.full_name AS created_by_name, u.badge_number AS created_by_badge,
                    fu.full_name AS finalized_by_name
             FROM reports r
             JOIN users u ON u.id = r.created_by
             LEFT JOIN users fu ON fu.id = r.finalized_by
             WHERE r.id = :id'
        );
        $stmt->execute([':id' => (int) $id]);
        $report = $stmt->fetch();
        if ($report === false || $report['deleted_at'] !== null) {
            Response::json(404, ['error' => 'Report not found.']);
        }
        if (!ReportVerification::mayViewForVerification($user, $report)) {
            Response::json(403, ['error' => 'You can only open reports you recorded.']);
        }

        $vstmt = $pdo->prepare(
            'SELECT v.*, u.full_name AS verifier_name, r.name AS verifier_role
             FROM report_verifications v
             JOIN users u ON u.id = v.verifier_id
             JOIN roles r ON r.id = u.role_id
             WHERE v.report_id = :rid ORDER BY v.id DESC'
        );
        $vstmt->execute([':rid' => (int) $id]);
        $verifications = $vstmt->fetchAll();
        $status = ReportVerification::status($report, $verifications);

        // The blotter-capture photos filed against this report (migration
        // 025), oldest first: the draft sheet draws each photo beside the
        // narrative it produced, so the officer checks image against text.
        $captures = CapturesController::listFor($pdo, (int) $id);
        Response::json(200, [
            'report' => $report,
            'station' => Station::header(),
            // The freed letterhead (doc, style, seals) travels with the header
            // so Write Report and print render exactly what Station Settings
            // saved — no second request, no stale fallback.
            'letterhead_html' => Station::letterheadHtml(),
            'letterhead_style' => Station::letterheadStyle(),
            'seal_left_url' => StationSeal::url('left', Station::sealPath('left')),
            'seal_right_url' => StationSeal::url('right', Station::sealPath('right')),
            'verification_status' => $status['code'],
            'verification_label' => $status['label'],
            'verifications' => $verifications,
            'captures' => $captures,
        ]);
    }

    public function printData(string $id): void
    {
        $user = Auth::requireUser();
        $pdo = Database::pdo();

        $stmt = $pdo->prepare(
            'SELECT r.*, u.full_name AS created_by_name, u.badge_number AS created_by_badge,
                    fu.full_name AS finalized_by_name
             FROM reports r
             JOIN users u ON u.id = r.created_by
             LEFT JOIN users fu ON fu.id = r.finalized_by
             WHERE r.id = :id'
        );
        $stmt->execute([':id' => (int) $id]);
        $report = $stmt->fetch();
        if ($report === false || $report['deleted_at'] !== null) {
            Response::json(404, ['error' => 'Report not found.']);
        }
        // Visibility: own reports or Admin, PLUS the Stage 4 verification
        // extension — an account recorded as reading a translated report's
        // source language may open it to review (read-only; only reports that
        // have a source).
        if (!ReportVerification::mayViewForVerification($user, $report)) {
            Response::json(403, ['error' => 'You can only open reports you recorded.']);
        }

        Audit::log((int) $user['id'], 'report.print', 'report', (string) (int) $id);
        // The sheet's fixed letterhead travels with the report so the printed
        // document never depends on a second request (spec §1.1). The
        // verification status and records travel with it too, so the appendix
        // is rendered from the SAME derivation as every other surface.
        $vstmt = $pdo->prepare(
            'SELECT v.*, u.full_name AS verifier_name, r.name AS verifier_role
             FROM report_verifications v
             JOIN users u ON u.id = v.verifier_id
             JOIN roles r ON r.id = u.role_id
             WHERE v.report_id = :rid ORDER BY v.id DESC'
        );
        $vstmt->execute([':rid' => (int) $id]);
        $verifications = $vstmt->fetchAll();
        $status = ReportVerification::status($report, $verifications);
        // The blotter-capture photos filed against this report (migration
        // 025), oldest first: the draft sheet draws each photo beside the
        // narrative it produced, so the officer checks image against text.
        $captures = CapturesController::listFor($pdo, (int) $id);
        Response::json(200, [
            'report' => $report,
            'station' => Station::header(),
            // Same freed letterhead as show(): the printed sheet must wear
            // what Station Settings saved.
            'letterhead_html' => Station::letterheadHtml(),
            'letterhead_style' => Station::letterheadStyle(),
            'seal_left_url' => StationSeal::url('left', Station::sealPath('left')),
            'seal_right_url' => StationSeal::url('right', Station::sealPath('right')),
            'verification_status' => $status['code'],
            'verification_label' => $status['label'],
            'verifications' => $verifications,
            'captures' => $captures,
        ]);
    }

    public function history(string $id): void
    {
        $user = Auth::requireUser();
        $pdo = Database::pdo();

        // Visibility rule: non-admin accounts may inspect history only for
        // reports they recorded; Admins may inspect any report's history.
        $ownerStmt = $pdo->prepare('SELECT created_by FROM reports WHERE id = :id');
        $ownerStmt->execute([':id' => (int) $id]);
        $owner = $ownerStmt->fetchColumn();
        if ($owner === false) {
            Response::json(404, ['error' => 'Report not found.']);
        }
        if (!in_array($user['role'], ['Admin', 'Officer'], true) && (int) $owner !== (int) $user['id']) {
            Response::json(403, ['error' => 'You can only view history for reports you recorded.']);
        }

        $stmt = $pdo->prepare(
            'SELECT h.id, h.change_note, h.snapshot, h.created_at, u.full_name AS changed_by
             FROM report_history h JOIN users u ON u.id = h.changed_by
             WHERE h.report_id = :id ORDER BY h.created_at DESC'
        );
        $stmt->execute([':id' => (int) $id]);
        Response::json(200, ['history' => $stmt->fetchAll()]);
    }

    private function fetchReport(PDO $pdo, int $id): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM reports WHERE id = :id AND deleted_at IS NULL');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /**
     * Phase 6 Stage 4 (D5) — attach the derived verification status to each row
     * in ONE batched query, using the single status function. The rows must
     * carry `narrative` and `narrative_source_text` for the hash comparison; the
     * caller decides whether those columns are stripped from the response
     * (the list strips them; the export never prints them).
     *
     * @param array<int, array<string,mixed>> $rows
     * @return array<int, array<string,mixed>>
     */
    private function attachVerificationStatus(PDO $pdo, array $rows): array
    {
        if ($rows === []) {
            return $rows;
        }
        $place = [];
        $params = [];
        foreach (array_values($rows) as $i => $row) {
            $key = ":rv{$i}";
            $place[] = $key;
            $params[$key] = (int) $row['id'];
        }
        $stmt = $pdo->prepare(
            'SELECT * FROM report_verifications WHERE report_id IN (' . implode(', ', $place) . ') ORDER BY id DESC'
        );
        $stmt->execute($params);
        $byReport = [];
        foreach ($stmt->fetchAll() as $v) {
            $byReport[(int) $v['report_id']][] = $v;
        }
        foreach ($rows as &$row) {
            $status = ReportVerification::status($row, $byReport[(int) $row['id']] ?? []);
            $row['verification_status'] = $status['code'];
            $row['verification_label'] = $status['label'];
        }
        unset($row);
        return $rows;
    }

    private function snapshot(PDO $pdo, int $reportId, int $userId, string $note): void
    {
        $stmt = $pdo->prepare('SELECT * FROM reports WHERE id = :id');
        $stmt->execute([':id' => $reportId]);
        $row = $stmt->fetch();
        if ($row === false) {
            return;
        }
        $ins = $pdo->prepare(
            'INSERT INTO report_history (report_id, changed_by, change_note, snapshot) VALUES (:rid, :uid, :note, :snap)'
        );
        $ins->execute([
            ':rid' => $reportId,
            ':uid' => $userId,
            ':note' => $note,
            ':snap' => json_encode($row, JSON_UNESCAPED_UNICODE),
        ]);
    }

    /**
     * Read the official-document fields off a request body (spec §1.2), with
     * their validation errors routed into the shared Validator.
     *
     * @param array<string, mixed> $body
     * @return array<string, mixed> normalized values (null = absent/blank)
     */
    private function officialFields(array $body, Validator $v, bool $finalizing = false, ?array $stored = null): array
    {
        $pick = static function (array $b, string $key): ?string {
            if (!array_key_exists($key, $b) || $b[$key] === null) {
                return null;
            }
            $val = trim((string) $b[$key]);
            return $val === '' ? null : $val;
        };

        $values = [
            'report_date' => $pick($body, 'report_date'),
            'blotter_no' => $pick($body, 'blotter_no'),
            'blotter_date' => $pick($body, 'blotter_date'),
            'incident_date' => $pick($body, 'incident_date'),
            'incident_time' => $pick($body, 'incident_time'),
            'discovery_date' => $pick($body, 'discovery_date'),
            'discovery_time' => $pick($body, 'discovery_time'),
            // Reporting party + signature block (migration 006, the Submit
            // Report screen's Panels I and IV). Kept on the report row with
            // the other document fields: these are what the filing party
            // declared, not per-type detail.
            'reporter_name' => $pick($body, 'reporter_name'),
            'reporter_contact' => $pick($body, 'reporter_contact'),
            'reporter_address' => $pick($body, 'reporter_address'),
        ];

        // Shapes first (one message per field, the codebase's usual style),
        // then the relational checks from the rule engine.
        foreach (['report_date', 'blotter_date', 'incident_date', 'discovery_date'] as $key) {
            if ($values[$key] !== null) {
                $v->date($key, $values[$key], ucfirst(str_replace('_', ' ', $key)));
            }
        }
        foreach (['incident_time', 'discovery_time'] as $key) {
            if ($values[$key] !== null) {
                $v->time($key, $values[$key], ucfirst(str_replace('_', ' ', $key)));
            }
        }

        $flags = [];
        foreach (['incident_time_approximate', 'discovery_time_approximate'] as $key) {
            $raw = $body[$key] ?? null;
            if ($raw !== null) {
                $v->boolean($key, $raw, ucfirst(str_replace('_', ' ', $key)));
            }
            $flags[$key] = $raw === true || $raw === 1 || $raw === '1';
        }

        $checked = ReportRules::validateOfficialFields($values);
        foreach ($checked['errors'] as $field => $msg) {
            $v->add($field, $msg);
        }

        // Reporting party / officer initials (migration 006): lengths here,
        // shapes in the rule engine.
        foreach ([
            'reporter_name' => ['Reporting party name', 160],
            'reporter_contact' => ['Contact number', 40],
            'reporter_address' => ['Home address', 255],
        ] as $key => [$label, $max]) {
            $v->optional($key, $values[$key], $label, $max);
        }
        // Gate 2 only: a name and a contact number are what a SUBMITTED report
        // cannot do without. A draft save passes them through unchecked, which is
        // what lets an officer start a report before the party will give a number.
        //
        // A PATCH may finalize without re-sending the party: those fields are
        // already on the row. So the check reads the EFFECTIVE row — the body
        // where it speaks, the stored row where it is silent — the same way the
        // finalize gate below reads the narrative, the Action Taken and the IOC.
        // What a PATCH WRITES is untouched by this; that is still decided by
        // which keys the body carried (see the $officialMap below).
        $partyValues = $values;
        if ($finalizing && is_array($stored)) {
            foreach (self::PARTY_FIELDS as $key) {
                if (!array_key_exists($key, $body)) {
                    $partyValues[$key] = $stored[$key] ?? null;
                }
            }
        }
        $party = ReportRules::validateReporterParty($partyValues, $finalizing);
        foreach ($party['errors'] as $field => $msg) {
            $v->add($field, $msg);
        }

        return ['values' => $values + $flags, 'warnings' => $checked['warnings']];
    }

    /** DATE + optional TIME → the derived sortable/queryable datetime. */
    private function composeDatetime(?string $date, ?string $time): string
    {
        $d = $date !== null && $date !== '' ? $date : date('Y-m-d');
        $t = $time !== null && $time !== '' ? $time : '00:00:00';
        if (strlen($t) === 5) {
            $t .= ':00';
        }
        return $d . ' ' . $t;
    }

    private function normalizeDt(string $value): string
    {
        $formats = ['Y-m-d H:i:s', 'Y-m-d\TH:i', 'Y-m-d\TH:i:s'];
        foreach ($formats as $f) {
            $dt = \DateTime::createFromFormat($f, $value);
            if ($dt !== false) {
                return $dt->format('Y-m-d H:i:s');
            }
        }
        return $value; // validator already rejects invalid values
    }

    private function fail(Validator $v): void
    {
        $errors = $v->errors();
        if ($errors !== []) {
            Response::json(422, ['error' => (string) reset($errors), 'fields' => $errors]);
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw === false || $raw === '') {
            return [];
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
}
