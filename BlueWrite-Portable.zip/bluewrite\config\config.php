<?php
/**
 * BlueWrite configuration — copy to config/config.php and fill in real values.
 * config/config.php is git-ignored and must never be committed.
 * This file lives SERVER-SIDE ONLY. Never reference secrets from frontend code.
 */

return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => '3306',
        'name' => 'bluewrite',
        'user' => 'bluewrite',
        'pass' => 'bw_local_2026',
    ],

    'app' => [
        // LAN deployment: the server's static IP, e.g. 'http://192.168.1.10'
        // Dev with Laragon vhost: 'http://bluewrite.test'
        'base_url' => 'http://192.168.0.107:8099',
        // The name the sign-in code email is signed with. Absent means
        // 'BlueWrite', which is what this machine wants — so it is not set here.
        // Session idle timeout in minutes (server-side enforcement).
        'session_idle_minutes' => 30,
        // Account lockout: N failed attempts locks the account for M minutes.
        // The same window applies to the email code's own counter
        // (email_otp_codes.failed_attempts).
        'lockout_attempts' => 5,
        'lockout_minutes' => 15,
    ],

    // ---- The second factor's mailer ------------------------------------------
    //
    // This block was MISSING on this machine, and its absence is not harmless:
    // every Admin/Officer sign-in generates a code and then fails to send it, so
    // /login answered 503 and nobody could get past the password. SEE ALSO the
    // schema: without migrations/013_email_otp.sql applied there is no
    // users.email and no email_otp_codes, and /login answers 500 instead.
    //
    // 'log' — the code is written to config/mail.log instead of being sent, so a
    //         sign-in completes on a machine with no Gmail account. The file is
    //         git-ignored. This is also what the PHPUnit suite requires: it has
    //         no other way to read the six digits (the DB keeps only a hash).
    // 'smtp' — the real Gmail transport. Requires a 16-character App Password
    //         from the SENDER account (Google Account -> Security -> App
    //         passwords; a normal account password is refused by smtp.gmail.com),
    //         pasted into 'app_password' with the spaces removed.
    //
    // SENDER AND RECIPIENT ARE TWO DIFFERENT THINGS, and they are free to be two
    // different accounts. 'username' below is WHO SENDS — one system account, the
    // same for every officer. The recipient is per-officer: users.email, read by
    // AuthController::sendCode() and never from this file. So the sender can be
    // pointed at a dedicated account without moving where the codes land.
    //
    // GMAIL WILL NOT LET THE TWO DIFFER. Authentication is as the sending
    // account, and the From: header is built from 'from_email' (blank means
    // 'username'), so a From that is not the authenticated account is refused or
    // rewritten unless it is a verified "Send mail as" alias on that account.
    // Keep them the same account and this cannot bite.
    'mail' => [
        'transport' => 'smtp',
        'host' => 'smtp.gmail.com',
        // 465 is implicit TLS (what this client opens) and 587 is STARTTLS.
        'port' => 465,
        'secure' => 'ssl',
        // WHO SENDS. One system account for every officer's sign-in code — not
        // the officer's own address (that is users.email, in the database).
        'username' => 'lo3507365@gmail.com',
        // A 16-character App Password from THAT account, spaces removed. IT IS
        // THE ONLY THING BETWEEN THIS AND REAL DELIVERY: with it blank the
        // transport cannot be 'smtp' (Mailer::configured() is false and every
        // sign-in answers 503). Generate it at Google Account -> Security -> App
        // passwords, which requires 2-Step Verification to be ON for the account.
        // A normal Gmail password is refused by smtp.gmail.com.
        'app_password' => 'ufcokvyayqrprteh',
        'from_name' => 'BlueWrite',
        // Blank sends as 'username'. Set it ONLY to a verified alias of the same
        // account — see the sender/recipient note above.
        'from_email' => '',
        'timeout' => 15,
    ],
];
